import java.lang.reflect.Array;

public class Carrinho {

    public Double precoBruto;
    public Double taxa;
    public Double precoTotal;
    public Array listaProd;

    public void FecharCompra;



}
