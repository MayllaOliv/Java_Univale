public class Product {
    private String name;
    private String description;
    private Double weight;
    private Double price;

    public void setName(String productName){
        name = productName;
    }

    public String getName() {
            return name;
    }
}
