public class Main {
     public static void main(String[] args) {
        Product rabanete = new Product();

        rabanete.setName("Rabanete");

        System.out.println(rabanete.getName());

    }
}