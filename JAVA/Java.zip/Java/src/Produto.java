public class Produto {

    public String nome;
    public Boolean desconto;
    public Double preso;
    public Double preco;



}
